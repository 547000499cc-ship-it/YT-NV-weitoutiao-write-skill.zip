# -*- coding: utf-8 -*-
"""
YT-NV 女性视角微头条批量写稿工具
支持3个命令：
  create [path]           - 创建空白模板xlsx
  read  [path]            - 读取待写主题（状态非"已写"且主题非空的行），输出JSON
  save  [path] [row] [file] - 将指定文件中的正文写入对应行的"正文"列，状态改为"已写"
"""
import sys
import json
import os

try:
    from openpyxl import Workbook, load_workbook
except ImportError:
    print(json.dumps({"error": "openpyxl not installed"}, ensure_ascii=False))
    sys.exit(1)

HEADERS = ["编号", "主题", "正文", "状态"]


def create_template(path):
    """创建空白模板xlsx"""
    wb = Workbook()
    ws = wb.active
    ws.title = "批量写稿"
    for col, header in enumerate(HEADERS, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = openpyxl_font_bold()
    # 设置列宽
    ws.column_dimensions["A"].width = 6    # 编号
    ws.column_dimensions["B"].width = 50   # 主题
    ws.column_dimensions["C"].width = 80   # 正文
    ws.column_dimensions["D"].width = 10   # 状态
    # 预留20个空行
    for i in range(1, 21):
        ws.cell(row=i + 1, column=1, value=i)
    wb.save(path)
    print(json.dumps({"ok": True, "path": path, "message": "模板创建成功"}, ensure_ascii=False))


def openpyxl_font_bold():
    from openpyxl.styles import Font
    return Font(bold=True)


def read_topics(path):
    """读取待写主题，返回JSON"""
    wb = load_workbook(path)
    ws = wb.active
    tasks = []
    for row in range(2, ws.max_row + 1):
        num = ws.cell(row=row, column=1).value
        topic = ws.cell(row=row, column=2).value
        content = ws.cell(row=row, column=3).value
        status = ws.cell(row=row, column=4).value
        if topic and str(topic).strip():
            if not status or str(status).strip() != "已写":
                tasks.append({
                    "row": row,
                    "编号": num,
                    "主题": str(topic).strip(),
                    "状态": status or "待写"
                })
    wb.close()
    print(json.dumps({"ok": True, "tasks": tasks, "count": len(tasks)}, ensure_ascii=False))


def save_content(path, row, content_file):
    """将正文文件内容写入xlsx对应行"""
    with open(content_file, "r", encoding="utf-8") as f:
        content = f.read().strip()
    wb = load_workbook(path)
    ws = wb.active
    row = int(row)
    ws.cell(row=row, column=3, value=content)
    ws.cell(row=row, column=4, value="已写")
    # 自动换行
    from openpyxl.styles import Alignment
    ws.cell(row=row, column=3).alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(path)
    wb.close()
    print(json.dumps({"ok": True, "row": row, "message": "正文已写入，状态已改为已写"}, ensure_ascii=False))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({"error": "用法: batch_write.py [create|read|save] [xlsx路径] [行号|正文文件]"}, ensure_ascii=False))
        sys.exit(1)
    cmd = sys.argv[1]
    xlsx_path = sys.argv[2]
    if cmd == "create":
        create_template(xlsx_path)
    elif cmd == "read":
        read_topics(xlsx_path)
    elif cmd == "save":
        if len(sys.argv) < 5:
            print(json.dumps({"error": "save命令需要: batch_write.py save [xlsx路径] [行号] [正文文件]"}, ensure_ascii=False))
            sys.exit(1)
        save_content(xlsx_path, sys.argv[3], sys.argv[4])
    else:
        print(json.dumps({"error": f"未知命令: {cmd}，支持 create/read/save"}, ensure_ascii=False))
        sys.exit(1)
